package GUI;

import javax.swing.*;

public class Detail_Page extends JFrame {

    public Detail_Page(){





    }


}
