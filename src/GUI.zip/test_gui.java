package GUI;

public class test_gui {

    public static void main(String[] args) {
        Login_Frame login_frame =new Login_Frame();

    }
}
